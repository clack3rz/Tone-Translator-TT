import React, { useState, useCallback, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'motion/react';
import AT5SignalChainView, { SignalChainNavTarget } from "./components/AT5SignalChainView";
import { ToneProfileView } from "./components/ToneProfileView";
import { GearManagementPanel } from './components/GearManagementPanel';
import { 
  Music, 
  Upload, 
  Zap, 
  Speaker, 
  Waves,
  ChevronRight,
  Info,
  Loader2,
  Guitar,
  Server,
  Box,
  Sliders,
  Cpu,
  Download,
  Activity,
  Copy,
  Check,
  Target,
  Mic2,
  FileJson,
  ShieldCheck,
  SlidersHorizontal,
  Gauge,
  Cable,
  Cuboid,
  X,
  LogIn,
  User,
  Database,
  RefreshCw,
  RotateCcw
} from 'lucide-react';
import { translateTone } from './services/geminiService';
import { copyToClipboard } from './utils/clipboard';
import { ToneResult } from './types';
import { parseAt5p, PresetData } from './services/presetParser';
import { getExportData, getExportDebugData } from './services/presetExporter';
import { GearSilhouette } from './components/GearSilhouette';
import { 
  KnobDefinition 
} from './services/gearManifest';
import { getGearIdentity } from './services/gearIdentity';
import { auth, signInWithGoogle } from './services/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { refreshCatalog } from './services/at5Catalog';
import { refreshProtocols } from './services/at5VerifiedProtocols';
import { refreshCoreParameterMappings, ensureMicPlacementDataLoaded } from './services/at5ParameterManifest';
import {
  loadWorkingSession,
  saveWorkingSession,
  clearWorkingSession,
  initSessionLifecycleDiagnostics,
  WorkingSessionData
} from './services/sessionStorage';
import { WorkspaceToolbar } from './components/WorkspaceToolbar';
import { RunTraceInspector } from './components/RunTraceInspector';
import {
  dispatchShadowRun,
  ShadowDispatchInputs,
  ShadowFaultMode,
  ShadowRunState,
  createSyntheticTraceForScenario,
} from './sound-engineer';

const STATUS_CONFIG: Record<string, { solid: string; clearBg: string; clearBorder: string; pulse: boolean }> = {
  pass: {
    solid: "#4ade80",
    clearBg: "rgba(74, 222, 128, 0.15)",
    clearBorder: "rgba(74, 222, 128, 0.40)",
    pulse: false
  },
  warn: {
    solid: "#eab308",
    clearBg: "rgba(234, 179, 8, 0.15)",
    clearBorder: "rgba(234, 179, 8, 0.40)",
    pulse: true
  },
  partial: {
    solid: "#f97316",
    clearBg: "rgba(249, 115, 22, 0.15)",
    clearBorder: "rgba(249, 115, 22, 0.40)",
    pulse: true
  },
  check: {
    solid: "#ea580c",
    clearBg: "rgba(234, 88, 12, 0.15)",
    clearBorder: "rgba(234, 88, 12, 0.45)",
    pulse: true
  },
  fail: {
    solid: "#dc2626",
    clearBg: "rgba(220, 38, 38, 0.15)",
    clearBorder: "rgba(220, 38, 38, 0.45)",
    pulse: true
  },
  skipped: {
    solid: "#ef4444",
    clearBg: "rgba(239, 68, 68, 0.15)",
    clearBorder: "rgba(239, 68, 68, 0.40)",
    pulse: true
  },
  critical: {
    solid: "#ef4444",
    clearBg: "rgba(239, 68, 68, 0.15)",
    clearBorder: "rgba(239, 68, 68, 0.55)",
    pulse: true
  },
  substituted: {
    solid: "#f43f5e",
    clearBg: "rgba(244, 63, 94, 0.15)",
    clearBorder: "rgba(244, 63, 94, 0.55)",
    pulse: true
  },
  normal: {
    solid: "#9ca3af",
    clearBg: "transparent",
    clearBorder: "rgba(255, 255, 255, 0.1)",
    pulse: false
  }
};

export default function App() {
  // Synchronous recovery check on mount
  const initialSessionRef = React.useRef<{ session: WorkingSessionData | null; restored: boolean } | null>(null);
  if (initialSessionRef.current === null) {
    initialSessionRef.current = loadWorkingSession();
  }
  const initialSession = initialSessionRef.current?.session;

  const [prompt, setPrompt] = useState(initialSession?.prompt || '');
  const [youtubeUrl, setYoutubeUrl] = useState(initialSession?.youtubeUrl || '');
  const [targetAudioFile, setTargetAudioFile] = useState<File | null>(null);
  const [recordingAudioFile, setRecordingAudioFile] = useState<File | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [abortController, setAbortController] = useState<AbortController | null>(null);
  const [toneResult, setToneResult] = useState<ToneResult | null>(initialSession?.toneResult || null);
  const [activeGearId, setActiveGearId] = useState<string | null>(initialSession?.activeGearId || null);
  const [error, setError] = useState<string | null>(null);
  const [userPreset, setUserPreset] = useState<PresetData | null>(initialSession?.userPreset || null);
  const [diffs, setDiffs] = useState<string[]>(initialSession?.diffs || []);
  const [activeVariation, setActiveVariation] = useState<'primary' | 'v1' | 'v2'>(initialSession?.activeVariation || 'primary');
  const [isCopied, setIsCopied] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [exportFilename, setExportFilename] = useState(initialSession?.exportFilename || '');
  const [useValidationRecipes, setUseValidationRecipes] = useState(initialSession?.useValidationRecipes ?? false);
  const [isChainViewOpen, setIsChainViewOpen] = useState(initialSession?.isChainViewOpen ?? false);
  const [isAdvancedDebugOpen, setIsAdvancedDebugOpen] = useState(false);
  const [isGearToolOpen, setIsGearToolOpen] = useState(false);
  const [hasOpenedGearTool, setHasOpenedGearTool] = useState(false);
  const [gearToolTab, setGearToolTab] = useState<'discovery' | 'catalogue' | 'mappings'>('discovery');
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isDbRefreshing, setIsDbRefreshing] = useState(false);
  const [dbVersion, setDbVersion] = useState(0);
  const [catalogueSearchOverride, setCatalogueSearchOverride] = useState<string | undefined>(undefined);
  const [sourceOriginalIndex, setSourceOriginalIndex] = useState<number | null>(null);
  const [signalChainNavTarget, setSignalChainNavTarget] = useState<SignalChainNavTarget | null>(null);
  const [restoredBanner, setRestoredBanner] = useState<{ show: boolean; chainCount: number }>({
    show: !!(initialSessionRef.current?.restored && initialSession?.toneResult?.signal_chain?.length),
    chainCount: initialSession?.toneResult?.signal_chain?.length || 0
  });

  // Sound Engineer Phase 1A.4: Ephemeral Shadow State (Strictly not persisted)
  const [shadowModeEnabled, setShadowModeEnabled] = useState(false);
  const [shadowFaultMode, setShadowFaultMode] = useState<ShadowFaultMode>('normal');
  const [shadowState, setShadowState] = useState<ShadowRunState | null>(null);
  const [isTraceInspectorOpen, setIsTraceInspectorOpen] = useState(false);
  const activeShadowRunIdRef = React.useRef<string | null>(null);
  const shadowCancelRef = React.useRef<((reason?: string) => void) | null>(null);

  // Sound Engineer Phase 1B.4: Truthful Synthetic QA Trace representation for active Shadow run
  const shadowTrace = React.useMemo(() => {
    if (!shadowState || !shadowState.runId) return null;
    return createSyntheticTraceForScenario({
      runId: shadowState.runId,
      faultMode: shadowFaultMode,
      status: shadowState.status,
      startedAt: shadowState.startedAt,
      completedAt: shadowState.completedAt,
      error: shadowState.error,
      cancellationReason: shadowState.cancellationReason,
    });
  }, [shadowState, shadowFaultMode]);

  const handleCancelShadow = useCallback(() => {
    if (shadowCancelRef.current) {
      shadowCancelRef.current('Shadow run cancelled by user from dev panel');
    }
  }, []);

  const handleResetShadow = useCallback(() => {
    // Only allow reset if not currently running
    if (shadowState?.status === 'running') return;
    setShadowState(null);
    activeShadowRunIdRef.current = null;
    shadowCancelRef.current = null;
    setIsTraceInspectorOpen(false);
  }, [shadowState]);

  // Lifecycle diagnostics and restored banner auto-dismiss
  useEffect(() => {
    const cleanupDiagnostics = initSessionLifecycleDiagnostics();
    let bannerTimer: any = null;
    if (restoredBanner.show) {
      bannerTimer = setTimeout(() => {
        setRestoredBanner(prev => ({ ...prev, show: false }));
      }, 4000);
    }
    return () => {
      if (bannerTimer) clearTimeout(bannerTimer);
      cleanupDiagnostics();
    };
  }, []);

  // Debounced working session persistence
  useEffect(() => {
    if (toneResult || prompt.trim().length > 0 || userPreset) {
      saveWorkingSession({
        revision: 0,
        prompt,
        youtubeUrl,
        useValidationRecipes,
        activeVariation,
        exportFilename,
        toneResult,
        userPreset,
        diffs,
        activeGearId,
        isChainViewOpen
      }, false);
    }
  }, [prompt, youtubeUrl, useValidationRecipes, activeVariation, exportFilename, toneResult, userPreset, diffs, activeGearId, isChainViewOpen]);

  const handleClearWorkingSession = useCallback(() => {
    clearWorkingSession();
    setToneResult(null);
    setPrompt('');
    setYoutubeUrl('');
    setUserPreset(null);
    setDiffs([]);
    setActiveGearId(null);
    setExportFilename('');
    setRestoredBanner({ show: false, chainCount: 0 });
  }, []);

  useEffect(() => {
    if (isGearToolOpen) {
      setHasOpenedGearTool(true);
    }
  }, [isGearToolOpen]);

  const handleRefreshChain = useCallback(async () => {
    setIsDbRefreshing(true);
    await Promise.all([refreshCatalog(), refreshProtocols(), refreshCoreParameterMappings(true)]);
    setDbVersion(prev => prev + 1);
    setIsDbRefreshing(false);
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });

    // Initial data refresh - loads only core parameter mappings, deferring mic/VIR data
    const initDb = async () => {
      setIsDbRefreshing(true);
      await Promise.all([refreshCatalog(), refreshProtocols(), refreshCoreParameterMappings()]);
      setIsDbRefreshing(false);
    };
    initDb();

    return () => unsubscribe();
  }, []);
 
  const currentChain = React.useMemo(() => {
    if (!toneResult) return [];
    return toneResult.signal_chain || [];
  }, [toneResult]);

  const exportDebugData = React.useMemo(() => {
    if (!toneResult) return null;
    try {
      return getExportDebugData(toneResult, currentChain);
    } catch (e) {
      console.error("Failed to generate export debug data:", e);
      return null;
    }
  }, [toneResult, currentChain, dbVersion]);

  const handleGearClick = (link: any, index: number) => {
    setActiveGearId(`${link.name}-${index}`);
    
    if (!exportDebugData) return;

    // Match exactly by original index for stable debugging
    const item = [...(exportDebugData.exported_chain || []), ...(exportDebugData.skipped_gear || [])].find(
      (d) => d.original_index === index
    );

    if (item) {
      const cardId = `at5-chain-card-${item.slot_section}-${item.slot_index}-${item.normalized_name}`;
      const element = document.getElementById(cardId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
        // Add a temporary highlight class or handling
        element.classList.add('ring-2', 'ring-gear-accent', 'ring-offset-4', 'ring-offset-black');
        setTimeout(() => {
          element.classList.remove('ring-2', 'ring-gear-accent', 'ring-offset-4', 'ring-offset-black');
        }, 2000);
      }
    }
  };

  const getGearStatus = useCallback((link: any, index: number) => {
    if (!exportDebugData) return { type: 'normal', label: '', reason: '' };
    
    // Match by original index for 1:1 parity with the debug chain
    const item = [...(exportDebugData.exported_chain || []), ...(exportDebugData.skipped_gear || [])].find(
      (d) => d.original_index === index
    );
    
    if (!item) return { type: 'normal', label: '', reason: '' };

    const rawStatus = (item.final_status || "PASS") as string;
    const reason = item.reason || "";

    const hasParamFails = item.parameter_mapping_status === "MISMATCH" ||
      item.parameter_mapping_status === "FAILED" ||
      (item.mismatched_parameters && item.mismatched_parameters.length > 0) ||
      item.parameter_details?.some((p: any) => p.mapping_status === "FAIL" || p.mapping_status === "MISMATCH" || p.mapping_status === "FAIL_MAPPING_CONFIGURATION");

    const hasParamWarnings = (item.disparity_parameters && item.disparity_parameters.length > 0) ||
      (item.dropped_parameters && item.dropped_parameters.length > 0) ||
      item.parameter_mapping_status === "PARTIAL" ||
      item.parameter_mapping_status === "PARTIAL_WITH_FALLBACK" ||
      item.parameter_mapping_status === "UNVERIFIED" ||
      item.parameter_details?.some((p: any) => p.mapping_status === "DISPARITY" || p.mapping_status === "WARNING" || p.mapping_status === "SUCCESS_NEAREST_BAND" || p.mapping_status === "FALLBACK_USED" || p.conversion_warning);
    
    if (rawStatus === "FAIL" || hasParamFails) {
      return { type: 'fail', label: 'FAIL', reason: reason || 'Parameter validation mismatch' };
    }
    if (rawStatus === "SKIPPED") {
      return { type: 'skipped', label: 'SKIPPED', reason };
    }
    if (rawStatus === "CRITICAL") {
      return { type: 'critical', label: 'CRITICAL', reason };
    }
    if (rawStatus === "SUBSTITUTED_FALLBACK") {
      return { type: 'substituted', label: 'SUBSTITUTED', reason };
    }
    if (rawStatus === "CHECK") {
      return { type: 'check', label: 'CHECK', reason };
    }
    if (rawStatus === "PARTIAL" || rawStatus === "PARTIAL_WITH_FALLBACK") {
      return { type: 'partial', label: 'PARTIAL', reason };
    }
    if (rawStatus === "PASS_WITH_WARNING" || rawStatus === "WARN" || hasParamWarnings) {
      return { type: 'warn', label: 'WARN', reason: reason || 'Parameter conversion warnings detected' };
    }
    if (rawStatus === "PASS") {
      return { type: 'pass', label: 'PASS', reason };
    }

    // fallback mapping if final_status wasn't populated or was custom
    if (!item.exported) {
      return { type: 'skipped', label: 'SKIPPED', reason };
    }
    return { type: 'pass', label: 'PASS', reason };
  }, [exportDebugData]);

  const initiateExport = () => {
    if (!toneResult) return;
    const defaultName = `TT_${toneResult.tone_summary.style.substring(0, 15).replace(/[^a-z0-9]/gi, '_')}`;
    setExportFilename(defaultName);
    setIsExportModalOpen(true);
  };

  const handleExport = async (customName: string) => {
    if (!toneResult) return;

    setIsTranslating(true);

    try {
      await ensureMicPlacementDataLoaded();
      const data = getExportData(toneResult, currentChain);

      const finalName = customName.endsWith(".at5p")
        ? customName
        : `${customName}.at5p`;

      const blob = new Blob([data], { type: "application/octet-stream" });
      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = finalName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("Export failed:", err);
      setError("Preset Export failed. Please try again.");
    } finally {
      setIsTranslating(false);
      setIsExportModalOpen(false);
    }
  };

  const copyManifestAsText = () => {
    if (!toneResult) return;
    
    let text = `AMPLITUBE 5 TONE ARCHITECTURE MANIFEST\n`;
    text += `======================================\n\n`;
    
    currentChain.forEach((link, idx) => {
      text += `${idx + 1}. ${link.name.toUpperCase()} [${link.type}]\n`;
      text += `--------------------------------------\n`;
      
      Object.entries(link.settings).forEach(([name, value]) => {
        text += `${name.padEnd(20)} : ${value}\n`;
      });
      text += `\n`;
    });

    text += `CONFIDENCE: ${toneResult.confidence}%\n`;
    text += `ENGINE: V2.0_MASTER\n`;

    void copyToClipboard(text).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }).catch(() => {});
  };

  const onTargetDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setTargetAudioFile(acceptedFiles[0]);
    }
  }, []);

  const onRecordingDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setRecordingAudioFile(acceptedFiles[0]);
    }
  }, []);

  const onPresetDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      const text = await file.text();
      try {
        const parsed = parseAt5p(text);
        setUserPreset(parsed);
        if (toneResult) {
          // Compare logic might need update
          setDiffs(["Analysis completed with new engine"]);
        }
      } catch (err) {
        setError('Failed to parse Amplitube preset file.');
      }
    }
  }, [toneResult]);

  const { getRootProps: getTargetRootProps, getInputProps: getTargetInputProps, isDragActive: isTargetDragActive } = useDropzone({
    onDrop: onTargetDrop,
    accept: { 'audio/*': [] },
    multiple: false,
  });

  const { getRootProps: getRecordingRootProps, getInputProps: getRecordingInputProps, isDragActive: isRecordingDragActive } = useDropzone({
    onDrop: onRecordingDrop,
    accept: { 'audio/*': [] },
    multiple: false,
  });

  const { 
    getRootProps: getPresetRootProps, 
    getInputProps: getPresetInputProps, 
    isDragActive: isPresetDragActive 
  } = useDropzone({
    onDrop: onPresetDrop,
    accept: { 
      'application/octet-stream': ['.at5p'],
      'application/xml': ['.at5p', '.xml'],
      'text/xml': ['.at5p', '.xml'],
      'text/plain': ['.txt', '.at5p']
    },
    multiple: false,
  });

  const handleTranslate = async () => {
    if (!prompt && !targetAudioFile && !recordingAudioFile) {
      setError('Please provide a description or at least one audio file.');
      return;
    }

    setIsTranslating(true);
    setError(null);
    setSourceOriginalIndex(null);
    setSignalChainNavTarget({ type: 'summary', token: Date.now() });

    // Sound Engineer Phase 1A.4: Optional parallel Shadow observation run (completely non-blocking)
    if (shadowModeEnabled) {
      try {
        const shadowInputs: ShadowDispatchInputs = {
          userText: prompt || "Synchronizing tone architecture based on providing reference.",
          youtubeUrl: youtubeUrl || undefined,
          targetAudioFile: targetAudioFile ? { name: targetAudioFile.name, type: targetAudioFile.type, size: targetAudioFile.size } : null,
          recordingAudioFile: recordingAudioFile ? { name: recordingAudioFile.name, type: recordingAudioFile.type, size: recordingAudioFile.size } : null,
          userPreset: userPreset ? { name: userPreset.metadata?.presetName || exportFilename || "imported_preset.at5p", rawContent: JSON.stringify(userPreset) } : null,
          useValidationRecipes: Boolean(useValidationRecipes),
          faultMode: shadowFaultMode,
        };

        const dispatchResult = dispatchShadowRun(shadowInputs, (newState) => {
          // Guard: Late completion of an older Shadow run cannot overwrite displayed state of a newer run
          if (activeShadowRunIdRef.current === newState.runId) {
            setShadowState(newState);
          }
        });

        activeShadowRunIdRef.current = dispatchResult.runMetadata.runId;
        shadowCancelRef.current = dispatchResult.cancel;
        setShadowState(dispatchResult.controller.getState());
      } catch (shadowErr) {
        console.error("Shadow dispatch error (non-fatal for Current):", shadowErr);
      }
    }

    const controller = new AbortController();
    setAbortController(controller);

    try {
      const toBase64 = (file: File): Promise<{ base64: string; mimeType: string }> => {
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const base64 = (reader.result as string).split(',')[1];
            resolve({ base64, mimeType: file.type });
          };
          reader.readAsDataURL(file);
        });
      };

      const targetData = targetAudioFile ? await toBase64(targetAudioFile) : undefined;
      const recordingData = recordingAudioFile ? await toBase64(recordingAudioFile) : undefined;

      const toneResponse = await translateTone(
        prompt || "Synchronizing tone architecture based on providing reference.",
        targetData,
        recordingData,
        userPreset,
        controller.signal,
        youtubeUrl || undefined,
        useValidationRecipes
      );
      setToneResult(toneResponse);
      
      if (userPreset) {
        // Compare logic might need update but we'll try to find a proxy
        setDiffs(["Analysis completed with new engine"]);
      }
    } catch (err: any) {
      if (err.name === 'AbortError' || (err instanceof Error && err.message.includes('abort'))) {
        console.log('Analysis aborted by user');
        return;
      }
      if (err instanceof Error && err.message.includes('TimeoutError')) {
        setError('Analysis timed out. The tone might be too complex or the service is busy. Please try again.');
        return;
      }
      if (err?.message?.includes('429') || err?.status === 'RESOURCE_EXHAUSTED') {
        setError('Rate limit exceeded. Please wait a moment and try again.');
        return;
      }
      console.error(err);
      setError('Failed to translate tone. Please check your connection and try again.');
    } finally {
      setIsTranslating(false);
      setAbortController(null);
    }
  };

  const handleCancel = () => {
    if (abortController) {
      abortController.abort();
      setIsTranslating(false);
      setAbortController(null);
    }
  };

  const copyExportDebug = () => {
    if (!toneResult) return;
    const debug = getExportDebugData(toneResult, currentChain);
    void copyToClipboard(JSON.stringify(debug, null, 2)).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    }).catch(() => {});
  };

  const exportDebugJson = () => {
    if (!toneResult) return;
    const debug = getExportDebugData(toneResult, currentChain);
    const data = JSON.stringify(debug, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `debug_${new Date().getTime()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleJumpToCatalogue = (guid: string, originIndex?: number) => {
    setCatalogueSearchOverride(guid);
    setSourceOriginalIndex(originIndex !== undefined ? originIndex : null);
    setGearToolTab('catalogue');
    setIsGearToolOpen(true);
  };

  const handleReturnToSummary = () => {
    setIsGearToolOpen(false);
    setCatalogueSearchOverride(undefined);
    setSourceOriginalIndex(null);
    setSignalChainNavTarget({ type: 'summary', token: Date.now() });
  };

  const handleReturnToGearItem = () => {
    if (sourceOriginalIndex !== null && sourceOriginalIndex !== undefined) {
      setIsGearToolOpen(false);
      setCatalogueSearchOverride(undefined);
      setSignalChainNavTarget({ type: 'item', originalIndex: sourceOriginalIndex, token: Date.now() });
    } else {
      handleReturnToSummary();
    }
  };

  const handleCloseGearTool = () => {
    setIsGearToolOpen(false);
    setCatalogueSearchOverride(undefined);
    setSourceOriginalIndex(null);
    setSignalChainNavTarget({ type: 'summary', token: Date.now() });
  };

  return (
    <div className="flex flex-col h-screen bg-[#050505] text-white overflow-hidden selection:bg-gear-accent/30 font-sans">
      {/* 1. TOP-TIER: Header & Global Controls */}
      <header className="h-[60px] border-b border-white/10 flex items-center justify-between px-6 bg-black/40 backdrop-blur-md shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gear-accent rounded flex items-center justify-center shadow-[0_0_15px_rgba(245,158,11,0.3)]">
            <Guitar className="text-black w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-display font-bold tracking-tight leading-none">Tone Translator</h1>
            <p className="text-[9px] text-gray-500 uppercase tracking-widest mt-1">Amplitube AI // V2.0 MASTER</p>
          </div>
        </div>

        <div className="flex-1 max-w-2xl mx-12 flex items-center gap-3 px-6">
          <div className="flex-1 relative">
            <input 
              type="text" 
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the tone (e.g. Master of Puppets bridge...)"
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-4 pr-16 py-2 text-xs focus:border-gear-accent outline-none transition-all placeholder:text-gray-600 font-mono"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
              {prompt && (
                <button 
                  onClick={() => setPrompt('')}
                  className="p-1 hover:bg-white/10 rounded-full transition-all active:scale-90"
                  title="Clear description"
                >
                  <X className="w-3 h-3 text-gray-500 hover:text-white" />
                </button>
              )}
              <Sliders className="w-3.5 h-3.5 text-gray-700" />
            </div>
          </div>

          <label className="flex items-center gap-2 cursor-pointer group shrink-0">
            <div 
              className={`w-7 h-4 rounded-full p-0.5 transition-colors relative border border-white/10 ${useValidationRecipes ? 'bg-gear-accent' : 'bg-white/5'}`}
            >
              <div className={`w-2.5 h-2.5 bg-white rounded-full transition-transform ${useValidationRecipes ? 'translate-x-3' : 'translate-x-0'}`} />
            </div>
            <span className="text-[9px] font-mono text-gray-500 uppercase tracking-tighter group-hover:text-gray-300 select-none">Recipes</span>
            <input 
              type="checkbox" 
              className="hidden" 
              checked={useValidationRecipes} 
              onChange={(e) => setUseValidationRecipes(e.target.checked)} 
            />
          </label>

          <button 
            onClick={handleTranslate}
            disabled={isTranslating}
            className="px-6 py-2 bg-gear-accent hover:bg-yellow-500 text-black font-bold text-[10px] rounded-lg transition-all flex items-center gap-2 shrink-0 disabled:opacity-50 shadow-[0_0_20px_rgba(245,158,11,0.2)] uppercase tracking-widest"
          >
            {isTranslating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
            {isTranslating ? "ANALYZING..." : "GENERATE"}
          </button>
        </div>

          <div className="flex items-center gap-4">
            <div className="w-px h-4 bg-white/10" />
          <div className="text-[9px] font-mono text-gray-500 uppercase flex items-center gap-2 pr-2">
            <div className={`w-1.5 h-1.5 ${isDbRefreshing ? 'bg-amber-500' : 'bg-green-500'} rounded-full animate-pulse`} />
            {isDbRefreshing ? 'Syncing DB...' : 'Cloud Ready'}
          </div>

          <div className="w-px h-4 bg-white/10 mx-2" />

          {user ? (
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setIsGearToolOpen(!isGearToolOpen)}
                className={`flex items-center gap-2 px-3 py-1 rounded-full border transition-all text-[10px] font-mono uppercase tracking-tighter ${isGearToolOpen ? 'bg-gear-accent text-black border-gear-accent shadow-[0_0_15px_rgba(245,158,11,0.4)]' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'}`}
              >
                <Database className="w-3 h-3" />
                Discovery
              </button>

              <div className="flex items-center gap-2 px-3 py-1 bg-white/5 rounded-full border border-white/10 group hover:border-gear-accent/50 transition-colors">
              {user.photoURL ? (
                <img src={user.photoURL} alt="" className="w-4 h-4 rounded-full border border-white/20" referrerPolicy="no-referrer" />
              ) : (
                <User className="w-3 h-3 text-gray-500" />
              )}
              <span className="text-[10px] font-mono text-gray-400 group-hover:text-white transition-colors">{user.displayName?.split(' ')[0]}</span>
              <button onClick={() => auth.signOut()} className="text-[8px] text-gray-600 hover:text-red-400 transition-colors ml-1 uppercase">Out</button>
            </div>
          </div>
          ) : (
            <button 
              onClick={signInWithGoogle}
              className="flex items-center gap-2 px-3 py-1 bg-white/5 hover:bg-white/10 rounded-full border border-white/10 text-[10px] font-mono text-gray-400 hover:text-white transition-all uppercase tracking-tighter"
            >
              <LogIn className="w-3 h-3 text-gear-accent" />
              Sign In
            </button>
          )}
        </div>
      </header>

      {/* 2. TOP-TIER: Persistent Workspace & Development Toolbar (Phase 1A.4a) */}
      <WorkspaceToolbar
        shadowModeEnabled={shadowModeEnabled}
        onToggleShadowMode={setShadowModeEnabled}
        faultMode={shadowFaultMode}
        onChangeFaultMode={setShadowFaultMode}
        shadowState={shadowState}
        onCancelShadow={handleCancelShadow}
        onResetShadow={handleResetShadow}
        onOpenTraceInspector={() => setIsTraceInspectorOpen(true)}
        hasToneResult={Boolean(toneResult && toneResult.signal_chain && toneResult.signal_chain.length > 0)}
        hasActiveContent={Boolean(toneResult || prompt.trim().length > 0 || userPreset)}
        isDbRefreshing={isDbRefreshing}
        onRefreshChain={handleRefreshChain}
        onClearSession={handleClearWorkingSession}
        onExportPreset={initiateExport}
      />

      {/* Restored Session Notification */}
      <AnimatePresence>
        {restoredBanner.show && (
          <motion.aside
            aria-label="Session notification"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="fixed top-16 right-8 z-50 flex items-center gap-3 px-4 py-2 bg-slate-900/95 border border-emerald-500/40 rounded-lg shadow-xl shadow-black/50 backdrop-blur-md"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <div className="text-[11px] font-mono text-slate-200">
              Working session restored <span className="text-emerald-400 font-bold">({restoredBanner.chainCount} gear items)</span>
            </div>
            <button
              onClick={() => setRestoredBanner(prev => ({ ...prev, show: false }))}
              className="text-slate-400 hover:text-white ml-2 text-xs"
              title="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.aside>
        )}
      </AnimatePresence>

      <main className="flex-1 flex flex-col min-h-0 overflow-y-auto">
        <div className="p-8">
          {hasOpenedGearTool && (
            <div className={`max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-top-4 duration-500 ${isGearToolOpen ? '' : 'hidden'}`}>
              <GearManagementPanel 
                onRefreshChain={handleRefreshChain} 
                onClose={handleCloseGearTool} 
                onReturnToSummary={handleReturnToSummary}
                onReturnToGearItem={handleReturnToGearItem}
                sourceOriginalIndex={sourceOriginalIndex}
                initialSelectedGuid={catalogueSearchOverride}
                exportDebugData={exportDebugData}
              />
            </div>
          )}

          {!isGearToolOpen && (
            toneResult ? (
              <div className="max-w-6xl mx-auto space-y-12">
                {exportDebugData && (
                  <AT5SignalChainView 
                    debugData={exportDebugData} 
                    onJumpToCatalogue={handleJumpToCatalogue} 
                    rawRequest={prompt}
                    toneResult={toneResult}
                    requestedTarget={signalChainNavTarget}
                  />
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center text-center py-24 opacity-40">
                <div className="w-20 h-20 rounded-2xl border-2 border-dashed border-white/10 flex items-center justify-center mb-8">
                   <Music className="w-10 h-10 text-gray-600" />
                </div>
                <h3 className="text-gray-500 font-display font-bold text-xl uppercase tracking-widest mb-3">Modular Engine Offline</h3>
                <p className="text-[10px] text-gray-600 uppercase leading-relaxed tracking-[0.25em] font-mono max-w-sm">
                  Provide a tone description or reference signal to initialize signal chain synthesis.
                </p>
              </div>
            )
          )}
        </div>
      </main>


      {/* FOOTER: System Status Bar */}
      <footer className="h-[35px] border-t border-white/10 shrink-0 bg-[#050505] flex items-center justify-between px-8 z-40">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-[#f59e0b] rounded-full shadow-[0_0_8px_#f59e0b]" />
            <span className="text-[9px] font-mono text-gray-600 uppercase tracking-widest">Signal Connection: Secured</span>
          </div>
          <div className="w-px h-3 bg-white/5" />
          <div className="text-[9px] font-mono text-gray-700 uppercase tracking-tight flex items-center gap-2">
            <Activity className="w-3 h-3" />
            Core Clock: 128.00 BPM // Phase Locked
          </div>
        </div>
        <div className="flex items-center gap-6 text-[9px] font-mono text-gray-500 uppercase">
          {toneResult && `CONFIDENCE: ${toneResult.confidence}% // V2.0_MASTER`}
        </div>
        <div className="flex items-center gap-6">
          <div className="text-[9px] font-mono text-gray-800 uppercase tracking-[0.6em] font-bold">
            Tone Translator // Pro Edition 2026
          </div>
        </div>
      </footer>

      {/* Export Modal */}
      <AnimatePresence>
        {isExportModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
              onClick={() => setIsExportModalOpen(false)}
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="relative bg-gear-card border border-gear-accent/30 rounded-2xl p-8 w-full max-w-md shadow-[0_0_50px_rgba(255,165,0,0.15)]"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-10 h-10 bg-gear-accent/20 rounded-lg flex items-center justify-center border border-gear-accent/30">
                  <Download className="text-gear-accent w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-display font-bold text-white tracking-tight">Export Preset</h3>
                  <p className="text-[10px] font-mono text-gray-500 uppercase tracking-widest">Amplitube 5 (.at5p) Specification</p>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div>
                  <label className="block text-[10px] font-mono text-gray-500 uppercase mb-2 tracking-widest pl-1">Preset Filename</label>
                  <div className="relative">
                    <input 
                      autoFocus
                      type="text" 
                      value={exportFilename}
                      onChange={(e) => setExportFilename(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleExport(exportFilename)}
                      className="w-full bg-gear-bg border border-gear-border rounded-xl px-4 py-3 text-sm focus:border-gear-accent focus:ring-1 focus:ring-gear-accent outline-none text-white font-mono"
                      placeholder="My_Awesome_Tone"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-mono text-gray-600">.AT5P</span>
                  </div>
                </div>
                
                <div className="bg-gear-accent/5 rounded-lg p-3 border border-gear-accent/10">
                  <div className="flex gap-2">
                    <Info className="w-3 h-3 text-gear-accent shrink-0 mt-0.5" />
                    <div className="flex flex-col gap-1">
                      <p className="text-[10px] text-gear-accent/80 leading-relaxed italic">
                        { 'showSaveFilePicker' in window 
                          ? "Modern Browser Detected: The system will attempt to show a location picker." 
                          : "Legacy Browser: The file will save directly to your Downloads folder." }
                      </p>
                      <p className="text-[9px] text-gray-500 font-mono leading-tight">
                        PRO TIP: If the location picker doesn't appear, try opening this app in a <strong>New Tab</strong> to bypass iframe security.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setIsExportModalOpen(false)}
                  className="px-4 py-3 rounded-xl border border-gear-border text-gray-400 font-bold text-xs uppercase tracking-widest hover:bg-white/5 transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleExport(exportFilename)}
                  className="px-4 py-3 rounded-xl bg-gear-accent text-black font-bold text-xs uppercase tracking-widest hover:bg-yellow-500 transition-colors shadow-lg shadow-gear-accent/20"
                >
                  Save Preset
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sound Engineer Phase 1B.4: Dedicated Run Trace Inspector Modal */}
      <RunTraceInspector
        isOpen={isTraceInspectorOpen}
        onClose={() => setIsTraceInspectorOpen(false)}
        trace={shadowTrace}
      />
    </div>
  );
}

